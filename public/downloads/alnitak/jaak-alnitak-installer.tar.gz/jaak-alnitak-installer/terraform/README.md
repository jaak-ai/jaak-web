# Terraform — estado deseado de la solución 1:N

**Borrador. Nunca se ha ejecutado.** No hay clúster donde probarlo hasta que se resuelva T-002.1,
y `terraform` no está instalado en la máquina donde se escribió, así que **ni la sintaxis está
validada**. La validación es T-002.5.

Declara los operadores prerequisito, los namespaces, los secretos, la configuración, el clúster de
Elasticsearch y los tres workloads. Todo lo específico de un proveedor de nube entra por variable:
la StorageClass, las etiquetas y taints del nodo con GPU, y los endpoints de Postgres, Redis y el
almacén de objetos.

Lo que **no** hace, a propósito: crear la VPC, el clúster ni los node pools. Eso es de cada nube y
del cliente.

## Dos etapas

El primer `apply` sobre un clúster limpio **falla**, y no es un error de este código: el proveedor
de Kubernetes exige que un CRD exista al planificar, y el CRD de Elasticsearch lo instala el
propio operador de este módulo. La salida honesta son dos pasadas.

```bash
terraform init

# 1) Solo los operadores
terraform apply -target=helm_release.eck \
                -target=helm_release.gpu_operator

# 2) Todo lo demás
terraform apply
```

Si el cliente ya tiene los operadores, se apagan con `instalar_eck = false` y compañía, y una sola
pasada basta.

## Orden respecto a Ansible

```
terraform apply (etapa 1)  → operadores
terraform apply (etapa 2)  → namespaces, secretos, config, Elasticsearch, workloads
ansible-playbook site.yml  → migraciones, CA, índice, credencial, verificación
```

La API no pasará su sonda de disponibilidad hasta que Ansible haya publicado el CA de
Elasticsearch y creado el índice. Es lo esperado, no un fallo.

## La llave que firma las sesiones

Si `sso.private_key_pem` va vacía, el módulo genera una con el proveedor `tls`. Es cómodo para una
prueba y **malo para producción**: la llave privada queda en el estado de Terraform. En producción
hay que generarla fuera y pasarla como variable, o inyectarla con el gestor de secretos del
cliente.

Y tiene que ser **la misma en todas las réplicas** de la API: si cada pod generara la suya, un
inicio de sesión empezado en un pod y devuelto en otro fallaría de forma intermitente.

## Decisiones que están en el código y conviene no deshacer

- **La configuración va por fichero montado, no por variables de entorno.** Kubernetes descarta las
  variables con valor vacío y hay campos que necesitan quedar explícitamente vacíos.
- **El vectorizador lleva `--provider=cuda` explícito.** El valor por defecto del binario es CPU:
  sin ese argumento responde bien y rinde diez veces menos.
- **Las sondas del vectorizador son pacientes** — 60 segundos de espera inicial en disponibilidad,
  300 en vida. Cargar los modelos e inicializar CUDA es lento, y sondas impacientes lo reinician
  en bucle.
- **La sonda de disponibilidad de la API es `/readyz`, no `/healthz`.** La segunda devuelve 200 sin
  comprobar nada.
- **El límite de memoria de la API es 1 GiB.** Con 512 MiB hubo un OOMKilled en el entorno de
  origen.
- **Los nodos de datos de Elasticsearch se reparten en hosts distintos** por anti-afinidad
  requerida.
