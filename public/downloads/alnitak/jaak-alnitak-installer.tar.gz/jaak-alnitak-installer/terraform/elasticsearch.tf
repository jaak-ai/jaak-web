# El clúster de Elasticsearch, vía el CRD que instala ECK.
#
# Requiere que el CRD ya exista al planificar: aplicar operadores.tf primero.
# force_conflicts no es opcional aquí, y no es pereza.
#
# ECK, en cuanto reconcilia el recurso, se declara gestor de campos de
# `.spec.nodeSets` para escribir sus valores por defecto. A partir de ese
# momento CUALQUIER segundo `terraform apply` falla con
# "conflict with elastic-operator ... .spec.nodeSets", incluso sin cambios
# nuestros, y el módulo deja de ser idempotente: no se puede volver a aplicar
# para tocar otra cosa.
#
# Lo que declaramos aquí es el estado deseado del cliente, así que ante un
# choque con los valores por defecto del operador manda este fichero.
resource "kubernetes_manifest" "elasticsearch" {
  field_manager {
    force_conflicts = true
  }

  manifest = {
    apiVersion = "elasticsearch.k8s.elastic.co/v1"
    kind       = "Elasticsearch"
    metadata = {
      name      = "elasticsearch"
      namespace = var.namespace_elasticsearch
    }
    spec = merge(
      # secureSettings solo existe si hay claves que poner en el almacén seguro.
      # Con rol de IAM el complemento se autentica solo y el bloque sobra.
      length(kubernetes_secret.respaldos_s3) > 0 ? {
        secureSettings = [{ secretName = "es-respaldos-s3" }]
      } : {},
      {
        version = var.es_version
        nodeSets = [
          {
            name  = "master"
            count = var.es_master_nodes
            config = {
              "node.roles"            = ["master"]
              "node.store.allow_mmap" = true
            }
            podTemplate = {
              spec = {
                # Elasticsearch necesita este límite del kernel más alto que el
                # habitual. Es la única pieza que pide un contenedor privilegiado.
                initContainers = [{
                  name            = "sysctl"
                  securityContext = { privileged = true, runAsUser = 0 }
                  command         = ["sh", "-c", "sysctl -w vm.max_map_count=262144"]
                }]
                containers = [{
                  name = "elasticsearch"
                  env  = [{ name = "ES_JAVA_OPTS", value = "-Xms1g -Xmx1g" }]
                  resources = {
                    requests = { cpu = var.es_master_cpu, memory = "2Gi" }
                    limits   = { cpu = "1", memory = "2Gi" }
                  }
                }]
              }
            }
            volumeClaimTemplates = [{
              metadata = { name = "elasticsearch-data" }
              spec = {
                accessModes      = ["ReadWriteOnce"]
                storageClassName = var.es_storage_class
                resources        = { requests = { storage = "20Gi" } }
              }
            }]
          },
          {
            name  = "data"
            count = var.es_data_nodes
            config = {
              "node.roles"            = ["data", "ingest"]
              "node.store.allow_mmap" = true
            }
            podTemplate = {
              spec = {
                # Reparte los nodos de datos en hosts distintos: perder un host no
                # debe llevarse dos copias del mismo shard.
                affinity = {
                  podAntiAffinity = {
                    requiredDuringSchedulingIgnoredDuringExecution = [{
                      labelSelector = {
                        matchLabels = {
                          "elasticsearch.k8s.elastic.co/statefulset-name" = "elasticsearch-es-data"
                        }
                      }
                      topologyKey = "kubernetes.io/hostname"
                    }]
                  }
                }
                initContainers = [{
                  name            = "sysctl"
                  securityContext = { privileged = true, runAsUser = 0 }
                  command         = ["sh", "-c", "sysctl -w vm.max_map_count=262144"]
                }]
                containers = [{
                  name = "elasticsearch"
                  env  = [{ name = "ES_JAVA_OPTS", value = "-Xms${var.es_data_heap} -Xmx${var.es_data_heap}" }]
                  resources = {
                    requests = { cpu = var.es_data_cpu, memory = var.es_data_memoria }
                    limits   = { cpu = "16", memory = var.es_data_memoria }
                  }
                }]
              }
            }
            volumeClaimTemplates = [{
              metadata = { name = "elasticsearch-data" }
              spec = {
                accessModes      = ["ReadWriteOnce"]
                storageClassName = var.es_storage_class
                resources        = { requests = { storage = var.es_data_disco } }
              }
            }]
          }
        ]
    })
  }
  depends_on = [kubernetes_namespace.todos]
}
