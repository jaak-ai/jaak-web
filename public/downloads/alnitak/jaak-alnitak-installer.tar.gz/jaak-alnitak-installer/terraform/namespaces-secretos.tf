locals {
  namespaces = toset([var.namespace_api, var.namespace_vectorizador, var.namespace_elasticsearch])

  # La llave que firma las sesiones tiene que ser LA MISMA en todas las réplicas
  # de la API: si cada pod generara la suya, un login iniciado en uno y devuelto
  # en otro fallaría de forma intermitente.
  session_key = var.sso.private_key_pem != "" ? var.sso.private_key_pem : tls_private_key.sesiones[0].private_key_pem

  # Misma lógica para la pimienta de las API keys, y la misma advertencia: si la
  # genera este módulo queda en el estado de Terraform. En producción va por el
  # gestor de secretos del cliente. Cambiarla invalida todas las API keys ya
  # emitidas, porque sus hashes dejan de coincidir.
  api_key_pepper = var.api_key_pepper != "" ? var.api_key_pepper : random_password.pimienta[0].result

  # Vacía es un valor con significado: deshabilita el login por contraseña. Solo
  # se genera si se pide explícitamente.
  password_pepper = var.password_pepper != "" ? var.password_pepper : (
    var.generar_password_pepper ? random_password.pimienta_password[0].result : ""
  )
}

resource "random_password" "pimienta_password" {
  count   = (var.password_pepper == "" && var.generar_password_pepper) ? 1 : 0
  length  = 64
  special = false
}

# 32 bytes es el mínimo que exige internal/auth: con menos, GenerateAPIKey
# devuelve ErrInvalidServerPepper y no se puede emitir ninguna credencial.
resource "random_password" "pimienta" {
  count   = var.api_key_pepper == "" ? 1 : 0
  length  = 64
  special = false
}

resource "kubernetes_namespace" "todos" {
  for_each = local.namespaces
  metadata { name = each.value }
}

# Solo se genera si no se pasó una por variable. AVISO: queda en el estado de
# Terraform. Para producción, generarla fuera y pasarla como variable.
resource "tls_private_key" "sesiones" {
  count     = var.sso.private_key_pem == "" ? 1 : 0
  algorithm = "RSA"
  rsa_bits  = 2048
}

resource "kubernetes_secret" "registro" {
  for_each = local.namespaces
  metadata {
    name      = "registro-imagenes"
    namespace = each.value
  }
  type       = "kubernetes.io/dockerconfigjson"
  data       = { ".dockerconfigjson" = var.registro_credenciales }
  depends_on = [kubernetes_namespace.todos]
}

# Un solo secreto para la API. Sin él el pod queda en CreateContainerConfigError.
resource "kubernetes_secret" "api" {
  metadata {
    name      = "api-secretos"
    namespace = var.namespace_api
  }
  data = {
    ALNILAM_SSO_CLIENT_SECRET    = var.sso.client_secret
    ALNILAM_SSO_PRIVATE_KEY_PEM  = local.session_key
    ALNILAM_POSTGRES_USER        = var.postgres.user
    ALNILAM_POSTGRES_PASSWORD    = var.postgres.password
    ALNILAM_CROPSTORE_ACCESS_KEY = var.cropstore.access_key
    ALNILAM_CROPSTORE_SECRET_KEY = var.cropstore.secret_key
    ALNILAM_CROP_KEY             = var.cropstore.crop_key
    ALNILAM_AUTH_API_KEY_PEPPER  = local.api_key_pepper
    ALNILAM_AUTH_PASSWORD_PEPPER = local.password_pepper
    # La API key de Elasticsearch la crea Ansible, que es quien puede hablar con
    # el clúster una vez arriba. Se parchea en este mismo secreto.
  }
  depends_on = [kubernetes_namespace.todos]
  lifecycle {
    # Ansible añade ALNILAM_ELASTICSEARCH_API_KEY: no lo borres en el siguiente apply.
    ignore_changes = [data]
  }
}

# La configuración va por FICHERO montado, no por variables de entorno.
# Kubernetes descarta las variables con valor vacío, y hay campos que necesitan
# quedar explícitamente vacíos; con env vars se reaplicaría el valor por defecto
# en silencio. Eso ya provocó seis despliegues mal configurados.
resource "kubernetes_config_map" "api" {
  metadata {
    name      = "api-config"
    namespace = var.namespace_api
  }
  data = {
    "config.yaml" = yamlencode({
      server = {
        port           = 8080
        rate_limit_max = var.rate_limit_max
        cors_origins   = "https://${var.host_publico}"
      }
      elasticsearch = {
        addresses      = ["https://elasticsearch-es-http.${var.namespace_elasticsearch}.svc:9200"]
        index          = var.indice
        ca_cert_path   = "/etc/es-ca/ca.crt"
        similarity     = "dot_product"
        external_index = false
        read_only      = false
        active_model   = "w600k_r50"
        # Los SIETE campos que la API admite, y los siete explícitos a propósito.
        # Sus valores por omisión están en español (`canal`, `alta`,
        # `vector_rostro`…) y la plantilla del índice los crea en inglés: si aquí
        # se omite uno, la API escribe en un nombre que el índice no tiene
        # mapeado, Elasticsearch lo crea al vuelo sin ser `keyword` y el
        # pre-filtro por ese campo deja de aprovechar el índice.
        fields = {
          vector        = "vector"
          id            = "id"
          tenant        = "tenant_id" # vacío aborta el arranque
          record        = "record"
          channel       = "channel"
          created_at    = "created_at"
          model_version = "model_version"
        }
      }
      vectorizer = {
        url        = "http://vectorizador.${var.namespace_vectorizador}.svc.cluster.local:8000"
        timeout_ms = 5000
      }
      identify = {
        default_top_n          = 10
        default_num_candidates = 800
        default_threshold      = 0.82 # SIN CALIBRAR: ver manual, limitación 4
      }
      postgres = {
        host    = var.postgres.host
        port    = var.postgres.port
        dbname  = var.postgres.dbname
        sslmode = var.postgres.sslmode
      }
      redis = { addr = var.redis_addr }
      cropstore = {
        endpoint = var.cropstore.endpoint
        region   = var.cropstore.region
        bucket   = var.cropstore.bucket
        use_ssl  = var.cropstore.use_ssl
      }
      sso = {
        client_id       = var.sso.client_id
        redirect_url    = "https://${var.host_publico}/auth/google/callback"
        console_url     = "https://${var.host_publico}"
        allowed_domains = var.sso.dominios
        operator_emails = var.sso.operadores
        session_ttl     = var.sso.session_ttl
      }
      sla = { latency_ms = 400, rps = 60 }
      log = { level = "info" }
    })
  }
  depends_on = [kubernetes_namespace.todos]
}
