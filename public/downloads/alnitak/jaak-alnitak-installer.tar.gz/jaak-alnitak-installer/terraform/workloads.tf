locals {
  etiquetas_vectorizador = { app = "vectorizador" }
  etiquetas_api          = { app = "api-1n" }
  etiquetas_consola      = { app = "consola-1n" }
}

# ---------------------------------------------------------------------------
# Vectorizador: el único que necesita GPU
# ---------------------------------------------------------------------------

resource "kubernetes_deployment" "vectorizador" {
  metadata {
    name      = "vectorizador"
    namespace = var.namespace_vectorizador
    labels    = local.etiquetas_vectorizador
  }
  spec {
    replicas = 1 # una GPU, una réplica. Escalar exige otra tarjeta.
    selector { match_labels = local.etiquetas_vectorizador }
    template {
      metadata { labels = local.etiquetas_vectorizador }
      spec {
        image_pull_secrets { name = "registro-imagenes" }
        node_selector = var.vectorizador_provider == "cuda" ? var.gpu_node_selector : {}

        # Sin esto el pod arranca con el runtime por omisión y sin CUDA: ver la
        # descripción de la variable.
        runtime_class_name = (var.vectorizador_provider == "cuda" && var.gpu_runtime_class != "") ? var.gpu_runtime_class : null

        dynamic "toleration" {
          for_each = var.vectorizador_provider == "cuda" ? var.gpu_tolerations : []
          content {
            key      = toleration.value.key
            operator = toleration.value.operator
            value    = try(toleration.value.value, null)
            effect   = toleration.value.effect
          }
        }

        security_context {
          run_as_user     = 1000
          run_as_group    = 1000
          run_as_non_root = true
        }

        container {
          name  = "vectorizador"
          image = var.imagen_vectorizador

          # El proveedor por defecto del binario es CPU. Sin --provider=cuda
          # responde bien y rinde diez veces menos.
          args = [
            "--addr=0.0.0.0:8000",
            "--provider=${var.vectorizador_provider}",
            "--workers=${var.vectorizador_workers}",
            "--max-inflight=${var.vectorizador_max_inflight}",
            "--request-timeout-ms=5000",
          ]

          port {

            name = "http"

            container_port = 8000

          }
          resources {
            requests = var.vectorizador_provider == "cuda" ? { cpu = "2", memory = "4Gi", "nvidia.com/gpu" = "1" } : { cpu = "2", memory = "4Gi" }
            limits   = var.vectorizador_provider == "cuda" ? { cpu = "8", memory = "12Gi", "nvidia.com/gpu" = "1" } : { cpu = "8", memory = "12Gi" }
          }

          # Cargar los modelos e inicializar CUDA es lento. Sondas impacientes
          # matan el arranque en bucle.
          readiness_probe {
            http_get {
              path = "/readyz"
              port = 8000
            }
            initial_delay_seconds = 60
            period_seconds        = 10
            failure_threshold     = 30
          }
          liveness_probe {
            http_get {
              path = "/healthz"
              port = 8000
            }
            initial_delay_seconds = 300
            period_seconds        = 15
            failure_threshold     = 6
          }
        }
      }
    }
  }
  depends_on = [kubernetes_secret.registro]
}

resource "kubernetes_service" "vectorizador" {
  metadata {
    name      = "vectorizador"
    namespace = var.namespace_vectorizador
  }
  spec {
    selector = local.etiquetas_vectorizador
    port {
      name = "http"
      port = 8000
      target_port = 8000
    }
  }
}

# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------

resource "kubernetes_deployment" "api" {
  metadata {
    name      = "api-1n"
    namespace = var.namespace_api
    labels    = local.etiquetas_api
  }
  spec {
    replicas = var.api_replicas
    selector { match_labels = local.etiquetas_api }
    template {
      metadata { labels = local.etiquetas_api }
      spec {
        image_pull_secrets { name = "registro-imagenes" }

        security_context {
          run_as_user     = 10001
          run_as_group    = 10001
          fs_group        = 10001
          run_as_non_root = true
        }

        container {
          name  = "api"
          image = var.imagen_api

          # Sin esto el binario leería el config horneado en la imagen, no el
          # ConfigMap montado.
          env {
            name  = "ALNILAM_CONFIG"
            value = "/etc/alnilam/config.yaml"
          }
          env_from {
            secret_ref { name = "api-secretos" }
          }

          port { container_port = 8080 }

          resources {
            requests = { cpu = "100m", memory = "512Mi" }
            limits   = { cpu = "1", memory = var.api_memoria_limite }
          }

          volume_mount {
            name       = "config"
            mount_path = "/etc/alnilam"
            read_only  = true
          }
          volume_mount {
            name       = "es-ca"
            mount_path = "/etc/es-ca"
            read_only  = true
          }

          liveness_probe {
            http_get {
              path = "/healthz"
              port = 8080
            }
            initial_delay_seconds = 15
            period_seconds        = 20
          }
          # /readyz sí comprueba Elasticsearch y el vectorizador; /healthz no
          # comprueba nada. La sonda de disponibilidad debe ser /readyz.
          readiness_probe {
            http_get {
              path = "/readyz"
              port = 8080
            }
            initial_delay_seconds = 10
            period_seconds        = 10
            failure_threshold     = 30
          }
        }

        volume {
          name = "config"
          config_map { name = "api-config" }
        }
        volume {
          name = "es-ca"
          # Lo crea Ansible tras extraer el CA de ECK: no existe antes.
          config_map {
            name     = "es-ca"
            optional = false
          }
        }
      }
    }
  }
  depends_on = [kubernetes_config_map.api, kubernetes_secret.api]
}

resource "kubernetes_service" "api" {
  metadata {
    name      = "api-1n"
    namespace = var.namespace_api
  }
  spec {
    selector = local.etiquetas_api
    port {
      port = 8080
      target_port = 8080
    }
  }
}

# ---------------------------------------------------------------------------
# Consola. Sirve la web y reenvía /api y /auth a la API, para que compartan
# origen: es obligatorio, ver manual sección 3.2.
# ---------------------------------------------------------------------------

resource "kubernetes_deployment" "consola" {
  metadata {
    name      = "consola-1n"
    namespace = var.namespace_api
    labels    = local.etiquetas_consola
  }
  spec {
    replicas = 2
    selector { match_labels = local.etiquetas_consola }
    template {
      metadata { labels = local.etiquetas_consola }
      spec {
        image_pull_secrets { name = "registro-imagenes" }
        container {
          name  = "consola"
          image = var.imagen_consola

          # Si este nombre no resuelve en DNS, nginx NO ARRANCA.
          env {
            name  = "API_UPSTREAM"
            value = "api-1n.${var.namespace_api}.svc.cluster.local:8080"
          }

          port { container_port = 80 }
          resources {
            requests = { cpu = "100m", memory = "128Mi" }
            limits   = { cpu = "500m", memory = "512Mi" }
          }
          readiness_probe {
            http_get {
              path = "/"
              port = 80
            }
            initial_delay_seconds = 5
          }
        }
      }
    }
  }
  depends_on = [kubernetes_service.api]
}

resource "kubernetes_service" "consola" {
  metadata {
    name      = "consola-1n"
    namespace = var.namespace_api
  }
  spec {
    selector = local.etiquetas_consola
    port {
      port = 80
      target_port = 80
    }
  }
}
