# Los cuatro prerrequisitos de plataforma. Cada uno se puede apagar porque el
# cliente puede tenerlos ya instalados: instalarlos dos veces rompe el clúster.
#
# IMPORTANTE: este fichero se aplica en una PRIMERA etapa, antes del resto.
# Terraform exige que los CRDs existan al planificar, y el CRD de Elasticsearch
# lo instala este operador. Ver README, "dos etapas".

resource "helm_release" "eck" {
  count            = var.instalar_eck ? 1 : 0
  name             = "elastic-operator"
  repository       = "https://helm.elastic.co"
  chart            = "eck-operator"
  version          = var.eck_version
  namespace        = "elastic-system"
  create_namespace = true
}

resource "helm_release" "gpu_operator" {
  count            = var.instalar_gpu_operator ? 1 : 0
  name             = "gpu-operator"
  repository       = "https://helm.ngc.nvidia.com/nvidia"
  chart            = "gpu-operator"
  version          = var.gpu_operator_version != "" ? var.gpu_operator_version : null
  namespace        = "gpu-operator"
  create_namespace = true

  # El operador detecta el driver del host. Si el cliente ya lo gestiona por su
  # cuenta, hay que desactivar su instalación aquí para no pisarlo.
  set {
    name  = "driver.enabled"
    value = "true"
  }
}

resource "helm_release" "prometheus" {
  count            = var.instalar_prometheus ? 1 : 0
  name             = "kube-prometheus-stack"
  repository       = "https://prometheus-community.github.io/helm-charts"
  chart            = "kube-prometheus-stack"
  version          = var.prometheus_version != "" ? var.prometheus_version : null
  namespace        = "monitoring"
  create_namespace = true
}

resource "helm_release" "external_secrets" {
  count            = var.instalar_external_secrets ? 1 : 0
  name             = "external-secrets"
  repository       = "https://charts.external-secrets.io"
  chart            = "external-secrets"
  version          = var.external_secrets_version != "" ? var.external_secrets_version : null
  namespace        = "external-secrets"
  create_namespace = true
}
