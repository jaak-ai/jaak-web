# ---------------------------------------------------------------------------
# Acceso al clúster
# ---------------------------------------------------------------------------

variable "kubeconfig_path" {
  description = "Ruta al kubeconfig del clúster del cliente."
  type        = string
  default     = "~/.kube/config"
}

variable "kube_context" {
  description = "Contexto de kubeconfig. Vacío usa el actual."
  type        = string
  default     = ""
}

# ---------------------------------------------------------------------------
# Operadores prerequisito. Cada uno se apaga si el cliente ya lo tiene.
# ---------------------------------------------------------------------------

variable "instalar_eck" {
  description = "Instalar el operador de Elastic Cloud on Kubernetes."
  type        = bool
  default     = true
}

variable "eck_version" {
  description = <<-EOT
    Versión del chart del operador de Elasticsearch.

    Se fija a propósito. Sin versión, Helm instala la última publicada el día de
    la instalación, de modo que dos despliegues de la misma entrega separados por
    unas semanas acaban con operadores distintos gobernando la galería, sin que
    nada en la configuración lo refleje y sin vuelta atrás determinista.

    Importa además porque es el operador quien decide qué versiones de
    Elasticsearch admite: uno más nuevo puede retirar el soporte de la versión
    fijada en `es_version`, y el fallo aparecería sin relación aparente con la
    causa.
  EOT
  type        = string
  default     = "3.5.0"
}

variable "prometheus_version" {
  description = "Versión del chart de Prometheus. Vacío instala la última publicada; fíjela para que la instalación sea reproducible."
  type        = string
  default     = ""
}

variable "external_secrets_version" {
  description = "Versión del chart del gestor de secretos externo. Vacío instala la última publicada."
  type        = string
  default     = ""
}

variable "gpu_operator_version" {
  description = "Versión del chart del operador de NVIDIA. Vacío instala la última publicada."
  type        = string
  default     = ""
}

variable "instalar_gpu_operator" {
  description = <<-EOT
    Instalar el GPU Operator de NVIDIA en el clúster.

    Por omisión NO se instala, y es deliberado: el manual lista este operador
    entre los prerrequisitos de plataforma que aporta el cliente, e instalar un
    operador de GPU en un clúster ajeno debe ser una decisión explícita, no un
    efecto secundario de dejar una variable sin tocar. Si el clúster ya expone
    `nvidia.com/gpu` —por el operador o por un device plugin puesto a mano—,
    activarlo instalaría uno encima.

    Con `false` y sin GPU expuesta, el preflight se detiene diciéndolo.
  EOT
  type        = bool
  default     = false
}

variable "instalar_prometheus" {
  description = "Instalar kube-prometheus-stack. La solución funciona sin él."
  type        = bool
  default     = false
}

variable "instalar_external_secrets" {
  description = "Instalar External Secrets Operator. Apagar si los secretos se crean por otra vía."
  type        = bool
  default     = false
}

# ---------------------------------------------------------------------------
# Namespaces
# ---------------------------------------------------------------------------

variable "namespace_api" {
  type    = string
  default = "biometria-1n"
}

variable "namespace_vectorizador" {
  type    = string
  default = "biometria-1n-gpu"
}

variable "namespace_elasticsearch" {
  type    = string
  default = "biometria-1n-datos"
}

# ---------------------------------------------------------------------------
# Imágenes de los componentes. Se entregan construidas, desde un registro privado.
# ---------------------------------------------------------------------------

variable "imagen_api" {
  description = "Imagen de la API. Usar etiqueta inmutable, nunca latest ni una mutable."
  type        = string
}

variable "imagen_vectorizador" {
  description = "Imagen del vectorizador, CON los modelos incluidos."
  type        = string
}

variable "imagen_consola" {
  type = string
}

variable "registro_credenciales" {
  description = "Contenido de un .dockerconfigjson para bajar las imágenes privadas."
  type        = string
  sensitive   = true
}

# ---------------------------------------------------------------------------
# Nodo con GPU. Etiquetas y taints los pone el clúster del cliente.
# ---------------------------------------------------------------------------

variable "gpu_node_selector" {
  description = "Selector del nodo con GPU. Depende de cómo el cliente etiquete sus nodos."
  type        = map(string)
  default     = { "nvidia.com/gpu.present" = "true" }
}

variable "gpu_tolerations" {
  description = "Taints a tolerar. Sin esto el pod de GPU no se programa nunca."
  type = list(object({
    key      = string
    operator = string
    value    = optional(string)
    effect   = string
  }))
  default = [{ key = "nvidia.com/gpu", operator = "Exists", effect = "NoSchedule" }]
}

variable "gpu_runtime_class" {
  description = <<-EOT
    RuntimeClass del contenedor con GPU. Vacía usa la del clúster por omisión.

    Hace falta siempre que el runtime de NVIDIA NO sea el runtime por omisión de
    containerd. Con el GPU Operator suele serlo y esto puede quedar vacío; en k3s,
    y en cualquier clúster donde `nvidia` sea una RuntimeClass más, sin esto el
    contenedor arranca con runc, sin las librerías de CUDA, y el proveedor CUDA de
    ONNX Runtime muere con un segfault por desreferencia de nulo.
  EOT
  type        = string
  default     = ""
}

variable "vectorizador_provider" {
  description = <<-EOT
    Proveedor de ejecución del vectorizador: "cuda" o "cpu".

    "cuda" es lo que se quiere y lo que mide el SLA. "cpu" existe porque hay
    casos reales en los que la GPU no está disponible —un entorno de prueba, o
    una tarjeta que otro trabajo necesita— y sin esta variable la única forma de
    seguir era editar el módulo. Con "cpu" no se piden recursos nvidia.com/gpu,
    no se aplica RuntimeClass ni selector de nodo, y el binario rinde
    aproximadamente diez veces menos: sirve para validar el flujo, NUNCA para
    medir rendimiento.
  EOT
  type        = string
  default     = "cuda"
  validation {
    condition     = contains(["cuda", "cpu"], var.vectorizador_provider)
    error_message = "vectorizador_provider tiene que ser \"cuda\" o \"cpu\"."
  }
}

variable "vectorizador_workers" {
  description = "Réplicas del motor dentro del proceso. Cada una carga su copia del modelo."
  type        = number
  default     = 4
}

variable "vectorizador_max_inflight" {
  description = "Peticiones simultáneas admitidas antes de responder 503. Es el control de admisión."
  type        = number
  default     = 128
}

# ---------------------------------------------------------------------------
# Elasticsearch
# ---------------------------------------------------------------------------

variable "es_version" {
  type    = string
  default = "9.5.2"
}

variable "es_storage_class" {
  description = "StorageClass de alto rendimiento. Ver los requisitos de IOPS en el manual, sección 3.1."
  type        = string
}

variable "es_data_nodes" {
  type    = number
  default = 3
}

variable "es_data_cpu" {
  description = <<-EOT
    CPU solicitada por cada nodo de datos de Elasticsearch.

    Es la petición que más pesa de toda la instalación: con el valor de
    producción, un solo nodo de datos consume la mitad de una máquina de 8 vCPU.
    Se deja configurable por el mismo motivo que la memoria: para poder validar
    en un equipo modesto sin tocar los manifiestos.

    Reducirla no cambia el comportamiento funcional, solo el rendimiento de la
    búsqueda.
  EOT
  type        = string
  default     = "4"
}

variable "es_master_cpu" {
  description = "CPU solicitada por cada nodo maestro de Elasticsearch."
  type        = string
  default     = "500m"
}

variable "vectorizador_cpu" {
  description = <<-EOT
    CPU solicitada por el vectorizador.

    Ojo: `vectorizador_provider = "cpu"` NO reduce esta petición. Ese ajuste
    solo evita reclamar `nvidia.com/gpu`; el consumo de CPU solicitado es el
    mismo en los dos modos. Para validar con recursos escasos hay que bajar
    también este valor.
  EOT
  type        = string
  default     = "2"
}

variable "es_data_memoria" {
  description = "Memoria por nodo de datos. El índice debe caber en RAM: ver manual, sección 4.1."
  type        = string
  default     = "100Gi"
}

variable "es_data_heap" {
  description = "Heap de la JVM. Regla práctica: la mitad de la memoria del nodo."
  type        = string
  default     = "16g"
}

variable "es_data_disco" {
  type    = string
  default = "400Gi"
}

variable "es_master_nodes" {
  type    = number
  default = 3
}

variable "indice" {
  description = "Nombre del índice de la galería. Debe coincidir con el que crea Ansible."
  type        = string
  default     = "galeria-biometrica-v1"
}

# ---------------------------------------------------------------------------
# Dependencias que provee el cliente
# ---------------------------------------------------------------------------

variable "postgres" {
  description = "Conexión de runtime. Las credenciales administrativas las usa Ansible, no esto."
  type = object({
    host     = string
    port     = optional(number, 5432)
    dbname   = string
    user     = string
    password = string
    sslmode  = optional(string, "require")
  })
  sensitive = true
}

variable "redis_addr" {
  description = "host:puerto de Redis. Vacío degrada a memoria de proceso: no dejar vacío con más de una réplica."
  type        = string
}

variable "redis_password" {
  description = <<-EOT
    Credencial de Redis. Vacía se conecta sin autenticar, que es lo único que
    admite un Redis sin `requirepass`.

    Redis guarda el estado de sesión compartido entre réplicas de la API. En un
    clúster compartido con otras aplicaciones conviene ponerla: sin credencial,
    cualquier carga capaz de abrir el puerto puede leer ese estado.
  EOT
  type        = string
  default     = ""
  sensitive   = true
}

variable "redis_username" {
  description = "Usuario de Redis. Solo hace falta con las ACL de Redis 6+; con `requirepass` basta la contraseña."
  type        = string
  default     = ""
  sensitive   = true
}

variable "cropstore" {
  description = "Almacén compatible con S3 para los recortes cifrados."
  type = object({
    endpoint   = string
    region     = string
    bucket     = string
    access_key = string
    secret_key = string
    use_ssl    = optional(bool, true)
    crop_key   = string # 32 bytes en hex o base64: cifra cada recorte
  })
  sensitive = true
}

variable "respaldos" {
  description = <<-EOT
    Contenedor compatible con S3 donde Elasticsearch deja las instantáneas de la
    galería, y cada cuándo las toma.

    Dejar `bucket` vacío DESACTIVA las instantáneas automáticas: la instalación
    funciona igual, pero la galería queda sin copia de seguridad y reconstruirla
    exige volver a vectorizar desde el contenedor de recortes.

    `access_key`/`secret_key` pueden ir vacías en AWS si los nodos del clúster ya
    tienen permiso de escritura sobre el contenedor por su rol de IAM.
  EOT
  type = object({
    bucket     = string
    region     = optional(string, "")
    endpoint   = optional(string, "") # vacío = S3 de AWS; se rellena para MinIO u otros
    access_key = optional(string, "")
    secret_key = optional(string, "")
    ruta       = optional(string, "galeria") # prefijo dentro del contenedor
    # Programación en formato cron de Elasticsearch (segundos minutos horas ...).
    # Por omisión, todos los días a las 01:30.
    programacion = optional(string, "0 30 1 * * ?")
    retener_dias = optional(number, 30)
    retener_min  = optional(number, 5)  # nunca conservar menos de estas
    retener_max  = optional(number, 50) # ni más de estas
  })
  default = {
    bucket = ""
  }
  sensitive = true
}

# ---------------------------------------------------------------------------
# Identidad y exposición
# ---------------------------------------------------------------------------

variable "host_publico" {
  description = "Host único de consola y API. Tienen que compartir origen: ver manual, sección 3.2."
  type        = string
}

variable "sso" {
  description = "Cliente OAuth de Google. Hoy no hay proveedor alternativo."
  type = object({
    client_id       = string
    client_secret   = string
    dominios        = list(string) # vacío DESACTIVA el acceso con Google; el proceso arranca igual
    operadores      = list(string) # sin esto nadie puede identificar
    session_ttl     = optional(string, "8h")
    private_key_pem = optional(string, "") # vacío: la genera este módulo, ver README
  })
  sensitive = true
}

variable "api_key_pepper" {
  description = <<-EOT
    Pimienta de servidor con la que se derivan los hashes de las API keys.
    Mínimo 32 bytes; vacía la genera este módulo.

    Sin ella la autenticación por API key NO funciona: el hash no se puede
    derivar ni verificar, así que no se pueden crear credenciales ni validar las
    existentes, y la consola con SSO de Google queda como única forma de entrar.
    El manual promete integraciones máquina a máquina por API key, así que esto
    no es opcional.

    Cambiarla INVALIDA todas las API keys ya emitidas: los hashes guardados
    dejan de coincidir. En producción va por el gestor de secretos del cliente,
    igual que la llave de sesión, y no en el estado de Terraform.
  EOT
  type        = string
  sensitive   = true
  default     = ""
}

variable "password_pepper" {
  description = <<-EOT
    Pimienta del hasheo de contraseñas de consola. Mínimo 32 bytes en
    base64url sin relleno; vacía DESHABILITA el login por contraseña y el
    endpoint responde 501.

    Es distinta de api_key_pepper a propósito: rotar la de las API keys es una
    operación normal que invalida las credenciales de servicio, y no debe dejar
    además a todas las personas fuera de la consola.

    Si se deja vacía y `generar_password_pepper` está activo, la genera este
    módulo — cómodo para una prueba y malo para producción, porque queda en el
    estado de Terraform. Ver la advertencia de la llave de sesión.
  EOT
  type        = string
  sensitive   = true
  default     = ""
}

variable "generar_password_pepper" {
  description = <<-EOT
    Generar la pimienta de contraseñas si `password_pepper` viene vacía.

    Por omisión NO: dejar la variable vacía tiene que significar "no quiero
    login por contraseña", no "genérame un secreto que no pedí". Un despliegue
    que estrena un endpoint de contraseñas sin saberlo es peor que uno que no lo
    tiene.
  EOT
  type        = bool
  default     = false
}

variable "api_replicas" {
  type    = number
  default = 2
}

variable "api_memoria_limite" {
  description = "512Mi provocó un OOMKilled en el entorno de origen. No bajar de 1Gi sin medir."
  type        = string
  default     = "1Gi"
}

variable "rate_limit_max" {
  description = "Peticiones por ventana y por IP. 0 lo desactiva y deja el borde sin freno."
  type        = number
  default     = 120
}
