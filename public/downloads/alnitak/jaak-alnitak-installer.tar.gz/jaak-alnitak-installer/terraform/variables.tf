# ---------------------------------------------------------------------------
# Acceso al clúster
# ---------------------------------------------------------------------------

variable "kubeconfig_path" {
  description = "Ruta al kubeconfig del clúster del cliente."
  type        = string
  default     = "~/.kube/config"
}

variable "kube_context" {
  description = "Contexto de kubeconfig. Vacío usa el actual."
  type        = string
  default     = ""
}

# ---------------------------------------------------------------------------
# Operadores prerequisito. Cada uno se apaga si el cliente ya lo tiene.
# ---------------------------------------------------------------------------

variable "instalar_eck" {
  description = "Instalar el operador de Elastic Cloud on Kubernetes."
  type        = bool
  default     = true
}

variable "instalar_gpu_operator" {
  description = <<-EOT
    Instalar el GPU Operator de NVIDIA en el clúster.

    Por omisión NO se instala, y es deliberado: el manual lista este operador
    entre los prerrequisitos de plataforma que aporta el cliente, e instalar un
    operador de GPU en un clúster ajeno debe ser una decisión explícita, no un
    efecto secundario de dejar una variable sin tocar. Si el clúster ya expone
    `nvidia.com/gpu` —por el operador o por un device plugin puesto a mano—,
    activarlo instalaría uno encima.

    Con `false` y sin GPU expuesta, el preflight se detiene diciéndolo.
  EOT
  type        = bool
  default     = false
}

variable "instalar_prometheus" {
  description = "Instalar kube-prometheus-stack. La solución funciona sin él."
  type        = bool
  default     = false
}

variable "instalar_external_secrets" {
  description = "Instalar External Secrets Operator. Apagar si los secretos se crean por otra vía."
  type        = bool
  default     = false
}

# ---------------------------------------------------------------------------
# Namespaces
# ---------------------------------------------------------------------------

variable "namespace_api" {
  type    = string
  default = "biometria-1n"
}

variable "namespace_vectorizador" {
  type    = string
  default = "biometria-1n-gpu"
}

variable "namespace_elasticsearch" {
  type    = string
  default = "biometria-1n-datos"
}

# ---------------------------------------------------------------------------
# Imágenes de los componentes. Se entregan construidas, desde un registro privado.
# ---------------------------------------------------------------------------

variable "imagen_api" {
  description = "Imagen de la API. Usar etiqueta inmutable, nunca latest ni una mutable."
  type        = string
}

variable "imagen_vectorizador" {
  description = "Imagen del vectorizador, CON los modelos incluidos."
  type        = string
}

variable "imagen_consola" {
  type = string
}

variable "registro_credenciales" {
  description = "Contenido de un .dockerconfigjson para bajar las imágenes privadas."
  type        = string
  sensitive   = true
}

# ---------------------------------------------------------------------------
# Nodo con GPU. Etiquetas y taints los pone el clúster del cliente.
# ---------------------------------------------------------------------------

variable "gpu_node_selector" {
  description = "Selector del nodo con GPU. Depende de cómo el cliente etiquete sus nodos."
  type        = map(string)
  default     = { "nvidia.com/gpu.present" = "true" }
}

variable "gpu_tolerations" {
  description = "Taints a tolerar. Sin esto el pod de GPU no se programa nunca."
  type = list(object({
    key      = string
    operator = string
    value    = optional(string)
    effect   = string
  }))
  default = [{ key = "nvidia.com/gpu", operator = "Exists", effect = "NoSchedule" }]
}

variable "gpu_runtime_class" {
  description = <<-EOT
    RuntimeClass del contenedor con GPU. Vacía usa la del clúster por omisión.

    Hace falta siempre que el runtime de NVIDIA NO sea el runtime por omisión de
    containerd. Con el GPU Operator suele serlo y esto puede quedar vacío; en k3s,
    y en cualquier clúster donde `nvidia` sea una RuntimeClass más, sin esto el
    contenedor arranca con runc, sin las librerías de CUDA, y el proveedor CUDA de
    ONNX Runtime muere con un segfault por desreferencia de nulo.
  EOT
  type        = string
  default     = ""
}

variable "vectorizador_provider" {
  description = <<-EOT
    Proveedor de ejecución del vectorizador: "cuda" o "cpu".

    "cuda" es lo que se quiere y lo que mide el SLA. "cpu" existe porque hay
    casos reales en los que la GPU no está disponible —un entorno de prueba, o
    una tarjeta que otro trabajo necesita— y sin esta variable la única forma de
    seguir era editar el módulo. Con "cpu" no se piden recursos nvidia.com/gpu,
    no se aplica RuntimeClass ni selector de nodo, y el binario rinde
    aproximadamente diez veces menos: sirve para validar el flujo, NUNCA para
    medir rendimiento.
  EOT
  type        = string
  default     = "cuda"
  validation {
    condition     = contains(["cuda", "cpu"], var.vectorizador_provider)
    error_message = "vectorizador_provider tiene que ser \"cuda\" o \"cpu\"."
  }
}

variable "vectorizador_workers" {
  description = "Réplicas del motor dentro del proceso. Cada una carga su copia del modelo."
  type        = number
  default     = 4
}

variable "vectorizador_max_inflight" {
  description = "Peticiones simultáneas admitidas antes de responder 503. Es el control de admisión."
  type        = number
  default     = 128
}

# ---------------------------------------------------------------------------
# Elasticsearch
# ---------------------------------------------------------------------------

variable "es_version" {
  type    = string
  default = "9.5.2"
}

variable "es_storage_class" {
  description = "StorageClass de alto rendimiento. Ver los requisitos de IOPS en el manual, sección 3.1."
  type        = string
}

variable "es_data_nodes" {
  type    = number
  default = 3
}

variable "es_data_memoria" {
  description = "Memoria por nodo de datos. El índice debe caber en RAM: ver manual, sección 4.1."
  type        = string
  default     = "100Gi"
}

variable "es_data_heap" {
  description = "Heap de la JVM. Regla práctica: la mitad de la memoria del nodo."
  type        = string
  default     = "16g"
}

variable "es_data_disco" {
  type    = string
  default = "400Gi"
}

variable "es_master_nodes" {
  type    = number
  default = 3
}

variable "indice" {
  description = "Nombre del índice de la galería. Debe coincidir con el que crea Ansible."
  type        = string
  default     = "galeria-biometrica-v1"
}

# ---------------------------------------------------------------------------
# Dependencias que provee el cliente
# ---------------------------------------------------------------------------

variable "postgres" {
  description = "Conexión de runtime. Las credenciales administrativas las usa Ansible, no esto."
  type = object({
    host     = string
    port     = optional(number, 5432)
    dbname   = string
    user     = string
    password = string
    sslmode  = optional(string, "require")
  })
  sensitive = true
}

variable "redis_addr" {
  description = "host:puerto de Redis. Vacío degrada a memoria de proceso: no dejar vacío con más de una réplica."
  type        = string
}

variable "cropstore" {
  description = "Almacén compatible con S3 para los recortes cifrados."
  type = object({
    endpoint   = string
    region     = string
    bucket     = string
    access_key = string
    secret_key = string
    use_ssl    = optional(bool, true)
    crop_key   = string # 32 bytes en hex o base64: cifra cada recorte
  })
  sensitive = true
}

# ---------------------------------------------------------------------------
# Identidad y exposición
# ---------------------------------------------------------------------------

variable "host_publico" {
  description = "Host único de consola y API. Tienen que compartir origen: ver manual, sección 3.2."
  type        = string
}

variable "sso" {
  description = "Cliente OAuth de Google. Hoy no hay proveedor alternativo."
  type = object({
    client_id       = string
    client_secret   = string
    dominios        = list(string) # vacío impide el arranque
    operadores      = list(string) # sin esto nadie puede identificar
    session_ttl     = optional(string, "8h")
    private_key_pem = optional(string, "") # vacío: la genera este módulo, ver README
  })
  sensitive = true
}

variable "api_key_pepper" {
  description = <<-EOT
    Pimienta de servidor con la que se derivan los hashes de las API keys.
    Mínimo 32 bytes; vacía la genera este módulo.

    Sin ella la autenticación por API key NO funciona: el hash no se puede
    derivar ni verificar, así que no se pueden crear credenciales ni validar las
    existentes, y la consola con SSO de Google queda como única forma de entrar.
    El manual promete integraciones máquina a máquina por API key, así que esto
    no es opcional.

    Cambiarla INVALIDA todas las API keys ya emitidas: los hashes guardados
    dejan de coincidir. En producción va por el gestor de secretos del cliente,
    igual que la llave de sesión, y no en el estado de Terraform.
  EOT
  type        = string
  sensitive   = true
  default     = ""
}

variable "password_pepper" {
  description = <<-EOT
    Pimienta del hasheo de contraseñas de consola. Mínimo 32 bytes en
    base64url sin relleno; vacía DESHABILITA el login por contraseña y el
    endpoint responde 501.

    Es distinta de api_key_pepper a propósito: rotar la de las API keys es una
    operación normal que invalida las credenciales de servicio, y no debe dejar
    además a todas las personas fuera de la consola.

    Si se deja vacía y `generar_password_pepper` está activo, la genera este
    módulo — cómodo para una prueba y malo para producción, porque queda en el
    estado de Terraform. Ver la advertencia de la llave de sesión.
  EOT
  type        = string
  sensitive   = true
  default     = ""
}

variable "generar_password_pepper" {
  description = <<-EOT
    Generar la pimienta de contraseñas si `password_pepper` viene vacía.

    Por omisión NO: dejar la variable vacía tiene que significar "no quiero
    login por contraseña", no "genérame un secreto que no pedí". Un despliegue
    que estrena un endpoint de contraseñas sin saberlo es peor que uno que no lo
    tiene.
  EOT
  type        = bool
  default     = false
}

variable "api_replicas" {
  type    = number
  default = 2
}

variable "api_memoria_limite" {
  description = "512Mi provocó un OOMKilled en el entorno de origen. No bajar de 1Gi sin medir."
  type        = string
  default     = "1Gi"
}

variable "rate_limit_max" {
  description = "Peticiones por ventana y por IP. 0 lo desactiva y deja el borde sin freno."
  type        = number
  default     = 120
}
