# Ansible — procedimientos de instalación

**Borrador. Nunca se ha ejecutado**, y sin clúster no se puede validar ni la sintaxis. La
validación es T-002.5.

Terraform declara el estado deseado. Aquí van los pasos que dependen del resultado del anterior y
que hay que verificar: las migraciones de base de datos, el certificado CA que no existe hasta que
ECK crea el clúster, la plantilla y el índice, la credencial de la API contra Elasticsearch, la
verificación, y la migración de un índice plano preexistente.

Corre desde la máquina del operador contra la API de Kubernetes. **No usa SSH.**

Si se configura `primer_admin_password`, el paso 2 le fija además una contraseña al primer
administrador y el paso 6 comprueba que esa vía quedó activa. Ver la sección 4.3 del manual.

## Requisitos

```bash
ansible-galaxy collection install kubernetes.core community.postgresql
pip install kubernetes psycopg2-binary
```

## Uso

```bash
cp group_vars_all.example.yml group_vars/all.yml   # y rellenar
ansible-playbook site.yml --tags preflight         # comprobar antes de tocar nada
ansible-playbook site.yml
```

La migración del índice plano está etiquetada `never`: solo corre si se pide, y exige confirmación
explícita porque su último tramo borra el índice de origen.

```bash
ansible-playbook site.yml --tags migracion -e confirmar_migracion=true
```

## Lo que hace cada paso

| Paso | Qué resuelve |
|---|---|
| `01-preflight` | Falla temprano si faltan los CRDs, un nodo con GPU, la StorageClass o Postgres |
| `02-postgres` | Migraciones con credenciales administrativas y alta del primer administrador |
| `03-es-ca` | Espera el clúster en verde, extrae el CA de ECK y lo publica donde la API lo monta |
| `04-index` | Plantilla e índice: 512 dimensiones, producto punto, int8 sobre HNSW |
| `05-api-key` | Crea la credencial de Elasticsearch **acotada al índice** y reinicia la API |
| `06-verification` | Comprueba que los tres workloads están arriba y que `/readyz` responde |
| `07-migrate-flat-index` | Solo si el cliente ya tenía galería con el nombre del alias |

## Dos advertencias

**El paso del CA hay que repetirlo.** El certificado se copia, no se referencia: cuando se renueve
o el clúster se recree, la API empieza a fallar su sonda de disponibilidad con "certificate signed
by unknown authority" hasta que se vuelva a correr `--tags elasticsearch`.

**El primer administrador es un paso obligatorio.** Sin él, el primer inicio de sesión queda como
lector y nadie puede administrar, aunque el SSO esté perfectamente configurado.

## Lo que estos scripts NO hacen

Generar las credenciales de las integraciones del cliente —eso pide decidir los permisos de cada
canal—, configurar el ingress y el TLS, que dependen de lo que el cliente use, y correr el guion de
humo de diez comprobaciones, que necesita una imagen real de una cara.
