#!/bin/sh
# Instalación de la solución 1:N en una sola orden.
#
# Envuelve la secuencia de cuatro invocaciones del manual (sección 7):
#
#   terraform apply -target=helm_release.eck   # 1) el operador
#   terraform apply                            # 2) todo lo demás — falla, y es normal
#   ansible-playbook site.yml                  # 3) migraciones, CA, credenciales, humo
#   terraform apply                            # 4) dejar el estado limpio
#
# El fallo de la invocación 2 es ESPERADO: la API no puede arrancar hasta que
# Ansible publique el certificado de Elasticsearch y su credencial. Este guion
# lo tolera ahí y SOLO ahí; cualquier otro fallo detiene todo.
#
# Requisitos previos (secciones 3 y 4 del manual): el clúster con sus
# operadores, PostgreSQL, Redis, el almacén S3 con sus dos buckets, y los dos
# ficheros de configuración rellenados desde sus ejemplos:
#   - terraform/terraform.tfvars
#   - ansible/group_vars/all.yml
set -u

AQUI=$(cd "$(dirname "$0")" && pwd)
TF="${TERRAFORM:-terraform}"
AP="${ANSIBLE_PLAYBOOK:-ansible-playbook}"

fallo() { echo; echo "INSTALACION DETENIDA: $1" >&2; exit 1; }

echo "== Comprobaciones previas =="
for b in "$TF" "$AP" kubectl; do
  command -v "$b" >/dev/null 2>&1 || {
    # Caso frecuente y desconcertante: `pipx install ansible` instala el
    # metapaquete, cuyo único punto de entrada es `ansible-community`, así que
    # ni ansible ni ansible-playbook quedan en el PATH aunque Ansible esté
    # instalado. Se resuelve reinstalando con --include-deps.
    if [ "$b" = "ansible-playbook" ] && command -v ansible-community >/dev/null 2>&1; then
      fallo "falta '$b' en el PATH, pero Ansible sí está instalado. Si lo instaló con pipx, reinstálelo con: pipx install --include-deps --force ansible"
    fi
    fallo "falta el binario '$b' en el PATH"
  }
done
# La rama de Terraform importa y el fallo, si no se comprueba aquí, aparece en la
# cuarta pasada: el peor momento para descubrir que la herramienta era otra.
TF_VER=$("$TF" version 2>/dev/null | head -1 | sed 's/^Terraform v//')
case "$TF_VER" in
  1.11.*) : ;;
  "")     fallo "no se pudo determinar la versión de Terraform con '$TF version'" ;;
  *)      fallo "Terraform $TF_VER no sirve: hace falta la rama 1.11.x. Las 1.12 y posteriores cambian el tratamiento de la identidad de recursos y la instalación falla al reaplicar. Ver la sección 0.1 del manual para instalarla" ;;
esac

[ -f "$AQUI/terraform/terraform.tfvars" ] || fallo "no existe terraform/terraform.tfvars: copia terraform.tfvars.example y rellénalo"
[ -f "$AQUI/ansible/group_vars/all.yml" ] || fallo "no existe ansible/group_vars/all.yml: copia group_vars_all.example.yml y rellénalo"
kubectl get nodes >/dev/null 2>&1 || fallo "kubectl no llega al clúster: revisa el kubeconfig y el contexto"

# Terraform se aplica sobre kube_context, NO sobre el contexto activo de kubectl.
# Los dos pueden apuntar a clústeres distintos sin que nada avise, y entonces la
# instalación va a parar a un sitio que nadie ha mirado. Se comprueba aquí.
CTX_TF=$(sed -n 's/^[[:space:]]*kube_context[[:space:]]*=[[:space:]]*"\(.*\)".*/\1/p' "$AQUI/terraform/terraform.tfvars" | head -1)
CTX_ACTIVO=$(kubectl config current-context 2>/dev/null)
if [ -n "$CTX_TF" ] && [ "$CTX_TF" != "$CTX_ACTIVO" ]; then
  echo
  echo "   El contexto de Terraform y el activo de kubectl NO coinciden:"
  echo "     kube_context (donde se instala): $CTX_TF"
  echo "     contexto activo de kubectl:      ${CTX_ACTIVO:-ninguno}"
  echo
  echo "   Las comprobaciones de este guion y los comandos de verificación del"
  echo "   manual usan el activo; la instalación usa el de Terraform. Si no es"
  echo "   deliberado, corrija uno de los dos antes de seguir."
  fallo "contextos distintos: revise kube_context en terraform/terraform.tfvars"
fi
echo "   binarios, configuraciones y clúster: OK"

cd "$AQUI/terraform" || fallo "no existe el directorio terraform/"

echo
echo "== 1/4: operador de Elasticsearch =="
"$TF" init -input=false >/dev/null || fallo "terraform init"
"$TF" apply -input=false -auto-approve -target=helm_release.eck || fallo "la etapa del operador"

echo
echo "== 2/4: namespaces, secretos, Elasticsearch y workloads =="
echo "   (esta etapa TERMINA EN ERROR esperando a la API: es el orden esperado)"
# Esta etapa termina en error a propósito: el Deployment de la API monta el
# certificado de Elasticsearch, que todavía no existe, así que espera y agota su
# plazo. Pero hay que comprobar que el error es ESE y no otro cualquiera: si se
# tolera cualquier fallo, un error de configuración —una variable mal puesta, por
# ejemplo— pasa por bueno aquí y la instalación se rompe tres pasos más adelante
# con un mensaje que no tiene nada que ver, del tipo «namespace not found».
#
# Sobre cómo se captura el resultado: NO se puede usar
#
#     if "$TF" apply ... 2>&1 | tee "$SALIDA"; then
#
# porque en una tubería el `if` evalúa el código de salida del ÚLTIMO comando,
# que es `tee`, y `tee` devuelve cero casi siempre. Con eso, la rama `else`
# —toda esta comprobación— nunca llega a ejecutarse y cualquier error pasa por
# bueno. `set -o pipefail` lo resolvería, pero no es portable en /bin/sh.
#
# La forma que funciona sin perder la salida en vivo: se mantiene el `tee` para
# ver el avance —esta etapa tarda de diez a quince minutos y sin salida parece
# colgada— y el código de Terraform se saca por un fichero aparte, escrito
# dentro de la misma agrupación antes de que la tubería llegue a `tee`.
SALIDA_ETAPA2="$(mktemp)"
CODIGO_ETAPA2_F="$(mktemp)"
{ "$TF" apply -input=false -auto-approve 2>&1; echo $? > "$CODIGO_ETAPA2_F"; } | tee "$SALIDA_ETAPA2"
CODIGO_ETAPA2=$(cat "$CODIGO_ETAPA2_F")
rm -f "$CODIGO_ETAPA2_F"

if [ "$CODIGO_ETAPA2" -eq 0 ]; then
  echo "   terminó sin error: instalación ya existente o la API arrancó a la primera"
else
  # Firmas del único fallo aceptable: esperas agotadas de rollout o de pods.
  if grep -qE "timed out waiting|context deadline exceeded|Waiting for rollout|Error: Waiting for" "$SALIDA_ETAPA2"; then
    echo "   error esperado recibido; la API queda a la espera del paso 3"
  else
    echo
    echo "   El error de esta etapa NO es el esperado. Lo esperado es una espera"
    echo "   agotada de la API; esto es otra cosa y hay que resolverlo antes de"
    echo "   seguir. Las últimas líneas:"
    echo
    grep -E "^│|Error:" "$SALIDA_ETAPA2" | tail -12 | sed "s/^/     /"
    rm -f "$SALIDA_ETAPA2"
    fallo "la etapa 2 falló por un motivo distinto al esperado"
  fi
fi
rm -f "$SALIDA_ETAPA2"

echo
echo "== 3/4: migraciones, certificado, credenciales y verificación =="
cd "$AQUI/ansible" || fallo "no existe el directorio ansible/"
"$AP" site.yml || fallo "el playbook de instalación (el mensaje de la tarea fallida dice qué esperaba)"

echo
echo "== 4/4: estado de Terraform limpio =="
cd "$AQUI/terraform"
"$TF" apply -input=false -auto-approve || fallo "la pasada final de terraform"

if "$TF" plan -input=false -detailed-exitcode >/dev/null 2>&1; then
  echo "   plan: sin cambios — instalación íntegra e idempotente"
else
  fallo "el plan final aún propone cambios: algo quedó a medias, revisa 'terraform plan'"
fi

echo
echo "== INSTALACION COMPLETA =="
echo "La verificación corrió dentro del playbook. Si configuraste imagen_prueba,"
echo "las pruebas de humo ya entraron como un usuario: login, API key, alta,"
echo "búsqueda, duplicado y revocación."
