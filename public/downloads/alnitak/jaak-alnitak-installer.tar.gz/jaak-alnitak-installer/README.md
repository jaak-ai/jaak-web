# jaak-alnitak-installer

Scripts de instalación de la solución de identificación biométrica facial 1:N sobre Kubernetes.

**El manual que los acompaña, y que explica qué hace cada paso, está en
<https://www.jaak.ai/docs/alnitak/instalacion>.** Estos scripts ejecutan lo que ese documento
describe; no son autoexplicativos por sí solos.

## Qué hay aquí

```
install.sh      Orquesta la secuencia completa. Es el punto de entrada.
terraform/      Estado deseado del despliegue sobre un clúster ya existente.
ansible/        Los pasos que dependen del resultado del paso anterior.
```

Los scripts **no crean el clúster ni las dependencias**: PostgreSQL, Redis, el almacén compatible
con S3 y el propio Kubernetes son responsabilidad de quien instala. El manual detalla los requisitos
de cada uno.

## Uso

```bash
cp terraform/terraform.tfvars.example terraform/terraform.tfvars
cp ansible/group_vars_all.example.yml ansible/group_vars/all.yml
# rellenar los dos ficheros: ver la sección 6.3 del manual

./install.sh
```

Termina con `INSTALACION COMPLETA` y código de salida 0. Cualquier otro final detiene la instalación
indicando la causa.

## Requisitos del equipo desde el que se instala

| Herramienta | Versión |
|---|---|
| `kubectl` | compatible con el clúster |
| `terraform` | **1.11.x** — no vale una posterior, ver la sección 0.1 del manual |
| `ansible` | 2.16 o superior, con la colección `kubernetes.core` y la librería de Python `kubernetes` |
| `psql` | 16 o superior |
| `openssl` | cualquiera reciente |

No hay requisito de sistema operativo: los guiones están escritos para `/bin/sh` sin construcciones
específicas de `bash`, y se han ejecutado desde Linux y desde macOS.

## Distribución

Este repositorio es la fuente. El paquete que descargan los clientes se publica en
<https://www.jaak.ai/downloads/alnitak/jaak-alnitak-installer.tar.gz> y se genera desde aquí:

```bash
tar -czf jaak-alnitak-installer.tar.gz \
  --transform 's,^,jaak-alnitak-installer/,' \
  install.sh terraform ansible
```

Cualquier cambio en estos scripts debe reflejarse en ese paquete y, si afecta a lo que el manual
describe, también en el manual.

## Configuración: qué NO va en este repositorio

Los ficheros `terraform.tfvars` y `ansible/group_vars/all.yml` contienen credenciales de base de
datos, claves del almacén de objetos y las pimientas de derivación. **Nunca deben subirse.** Aquí
solo viven sus plantillas de ejemplo, que no contienen ningún valor real.

El fichero de estado de Terraform tampoco: puede contener secretos generados durante la instalación.
